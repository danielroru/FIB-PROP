public class Enumeracio {
    public enum TipusSessio {
        TEORIA, LABORATORI, PROBLEMES
    }

    public enum TipusAula {
        TEORIA, LABORATORI
    }

    public enum Dia {
        DILLUNS, DIMARTS, DIMECRES, DIJOUS, DIVENDRES
    }
}
