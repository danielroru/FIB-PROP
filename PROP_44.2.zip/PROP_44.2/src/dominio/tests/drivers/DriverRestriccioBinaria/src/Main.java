import java.util.*;

public class Main {

    public static void menuDriverRestriccioUnaria() {
        System.out.println(" ");
        System.out.println("Menú Driver Restricció Unaria");
        System.out.println("-----------------------------");
        System.out.println("(El valor de l'opció ha de ser un número natural)");
        System.out.println(" ");
        System.out.println("1] Test Arestes Nivell");
        System.out.println("2] Test Valida Solució");
        System.out.println("3] Test Coincideixen UAH");
        System.out.println("4] Test Arestes Correquisit");
        System.out.println("Per acabar amb el Test introduir un altre valor.");
    }

    public static void main(String[] args) {

    }
}
